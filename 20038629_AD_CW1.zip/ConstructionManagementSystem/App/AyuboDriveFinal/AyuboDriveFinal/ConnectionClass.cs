﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AyuboDriveFinal
{
    public class ConnectionClass
    {
        public static string conn = @"Data Source=DESKTOP-HK99GPI\SQLEXPRESS;Initial Catalog=cmsdb;Integrated Security=True";
    }
}
